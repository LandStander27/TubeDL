# TubeDL
A command line tool that downloads youtube videos

YOU NEED FFMPEG FOR THIS TO WORK

Commands:
    Input: [Program name] [Option] [Link] [Video type] [-o]

    Options: -d, -i, -help
        -d: Download
        -i: Show info
        -help: Show this menu

    Video type: 144p, 240p, etc or -a for audio
    -o: Adding -o opens the file when done
